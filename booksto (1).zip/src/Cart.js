
// import React, { useState, useEffect } from 'react';
// import { Link } from 'react-router-dom';

// const Cart = () => {
//   const [cart, setCart] = useState([]);

//   useEffect(() => {
//     const savedCart = JSON.parse(localStorage.getItem('cart')) || [];
//     setCart(savedCart);
//   }, []);

//   return (
//     <div>
//       <h1>Your Cart</h1>
//       <ul>
//         {cart.map((item) => (
//           <li key={item.id}>
//             {item.title} - Quantity: {item.quantity}
//           </li>
//         ))}
//       </ul>
//       <Link to="/checkout">
//         <button>Proceed to Checkout</button>
//       </Link>
//     </div>
//   );
// };

// export default Cart;












import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Cart.css'; // Import the CSS file

const Cart = () => {
  const [cart, setCart] = useState([]);

  useEffect(() => {
    const savedCart = JSON.parse(localStorage.getItem('cart')) || [];
    setCart(savedCart);
  }, []);

  return (
    <div className="cart-container">
      <h1>Your Cart</h1>
      <ul>
        {cart.map((item) => (
          <li key={item.id}>
            {item.title} - Quantity: {item.quantity}
          </li>
        ))}
      </ul>
      <Link to="/checkout" className="link-button">
        <button>Proceed to Checkout</button>
      </Link>
    </div>
  );
};

export default Cart;

import React, { useState, useEffect } from 'react';
import './Checkout.css'; // Import the CSS file

const Checkout = () => {
  const [cart, setCart] = useState([]);

  useEffect(() => {
    // Fetch cart data from localStorage
    const savedCart = JSON.parse(localStorage.getItem('cart')) || [];
    setCart(savedCart);
  }, []);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="checkout-container">
      <h1>Checkout</h1>
      <h2>Invoice</h2>
      <ul>
        {cart.map((item) => (
          <li key={item.id}>
            {item.title} - Quantity: {item.quantity}
          </li>
        ))}
      </ul>
      <button onClick={handlePrint}>Print Invoice</button>
    </div>
  );
};

export default Checkout;

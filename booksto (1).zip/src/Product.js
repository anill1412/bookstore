// Product.js
import React from 'react';
import { useParams } from 'react-router-dom';
import './Product.css'; // Import the CSS file

const Product = () => {
  const { id } = useParams();
  const books = [
    { 
      id: 1, 
      title: 'The Great Gatsby', 
      description: 'A classic novel by F. Scott Fitzgerald where he explores how the world goes around the boy.',
      imageUrl: 'pic3.jpg'
    },
    { 
      id: 2, 
      title: 'A Silent Valley', 
      description: 'A dystopian novel by George Orwell where the protagonist will go on a hunt to kill the villain.',
      imageUrl: 'pic2.jpg'
    },
    { 
      id: 3, 
      title: 'To Kill a Mockingbird', 
      description: 'A novel by Harper Lee where the hero pursues a violent path and kills everyone.',
      imageUrl: 'pic1.webp'
    },
  ];

  // Find the book based on the ID from the URL
  const book = books.find((b) => b.id === parseInt(id));

  if (!book) {
    return <div>Book not found</div>;
  }

  const handleAddToCart = () => {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    const existingItem = cart.find((item) => item.id === book.id);

    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      cart.push({ ...book, quantity: 1 });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
  };

  return (
    <div className="card-container">
      <div className="card">
        <img 
          src={`${process.env.PUBLIC_URL}/${book.imageUrl}`} 
          alt={book.title} 
        />
        <h1>{book.title}</h1>
        <p>{book.description}</p>
        <button onClick={handleAddToCart}>Add to Cart</button>
      </div>
    </div>
  );
};

export default Product;

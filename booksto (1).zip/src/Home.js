import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css'; // Import the CSS file

const Home = () => {
  const books = [
    { 
      id: 1, 
      title: 'The Great Gatsby', 
      description: 'A classic novel by F. Scott Fitzgerald.',
      imageUrl: 'pic3.jpg' // Path relative to the public folder
    },
    { 
      id: 2, 
      title: 'A Silent Valley', 
      description: 'A dystopian novel by George Orwell.',
      imageUrl: 'pic2.jpg' // Path relative to the public folder
    },
    { 
      id: 3, 
      title: 'To Kill a Mockingbird', 
      description: 'A novel by Harper Lee.',
      imageUrl: 'pic1.webp' // Path relative to the public folder
    },
  ];

  return (
    <div>
      <h1>Book Store</h1>
      <div className="card-container">
        {books.map((book) => (
          <div className="card" key={book.id}>
            <Link to={`/product/${book.id}`}>
              <img 
                src={book.imageUrl} 
                alt={book.title} 
              />
              <div className="card-content">
                <h2 className="card-title">{book.title}</h2>
              </div>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Home;

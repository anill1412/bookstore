// Header.js
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Header.css'; // Import the CSS file

const Header = () => {
  const [itemCount, setItemCount] = useState(0);

  useEffect(() => {
    // Fetch cart data from localStorage
    const savedCart = JSON.parse(localStorage.getItem('cart')) || [];
    // Calculate the total number of items
    const totalItems = savedCart.reduce((acc, item) => acc + item.quantity, 0);
    setItemCount(totalItems);
  }, []);

  return (
    <header className="header">
      <nav>
        <ul className="nav-list">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/cart">Cart {itemCount > 0 && `(${itemCount})`}</Link></li>
          <li><Link to="/checkout">Checkout</Link></li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
